<?php

namespace App\Swagger;

/**
 * @OA\Info(
 *     version="1.0.0",
 *     title="Нууу очень крутая апишка",
 *     description="Документация для REST API Laravel",
 *     @OA\Contact(
 *         email="support@example.com"
 *     ),
 *     @OA\License(
 *         name="MIT",
 *         url="https://opensource.org/licenses/MIT"
 *     )
 * )
 *
 * @OA\Server(
 *     url="http://localhost/",
 *     description="Локальный сервер разработки"
 * )
 */
class OpenApi
{
}
