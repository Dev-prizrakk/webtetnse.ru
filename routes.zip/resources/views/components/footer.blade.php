<footer class="footer">
    <div class="container footer__wrap">
        <div class="footer__col">
            <p>© 2018–{{ date('Y') }} WEBTENSE. Все права защищены.</p>
            <a href="#">Политика конфиденциальности</a>
        </div>
        <div class="footer__col">
            <p>Контакты:</p>
            <a href="mailto:info@webtense.ru">info@webtense.ru</a>
            <a href="tel:+79107797314">+7 (910) 779-73-14</a>
        </div>
    </div>
</footer>
