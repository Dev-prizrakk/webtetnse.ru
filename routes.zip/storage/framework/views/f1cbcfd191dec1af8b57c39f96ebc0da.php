<section class="booklet">
  <div class="container booklet__wrap">
    <div class="booklet__left">
      <h2>Скачать сборник идей для разработки сайта</h2>
      <p class="accent">50 «лайфхаков», которые могут быть полезны при проектировании сайта</p>
      <form action="#" class="booklet__form">
        <input placeholder="Имя" required>
        <input placeholder="Телефон" required>
        <input placeholder="Email" required>
        <button class="btn btn-gradient" type="submit">Скачать книгу</button>
      </form>
    </div>
    <div class="booklet__right">
      <img src="<?php echo e(asset('images/booklet.png')); ?>" alt="">
    </div>
  </div>
</section>
<?php /**PATH /var/www/html/resources/views/components/booklet.blade.php ENDPATH**/ ?>