<?php $__env->startSection('content'); ?>
<h1>Авторизация / Регистрация</h1>

<?php if($errors->any()): ?>
<div class="errors">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="auth-container" style="display: flex; gap: 40px; justify-content: center; flex-wrap: wrap;">
    
    <div class="login-box" style="min-width: 300px;">
        <h2>Войти</h2>
        <form method="POST" action="<?php echo e(route('auth.login')); ?>">
            <?php echo csrf_field(); ?>
            <label for="email">Email</label>
            <input type="email" name="email" id="email" required>

            <label for="password">Пароль</label>
            <input type="password" name="password" id="password" required>

            <button type="submit">Войти</button>
        </form>

        <p style="margin-top: 10px; text-align: center;">
            <a href="<?php echo e(route('auth.forgot')); ?>" style="color: #3498db;">Забыли пароль?</a>
        </p>
    </div>

    
    <div class="register-box" style="min-width: 300px;">
        <h2>Регистрация</h2>
        <form method="POST" action="<?php echo e(route('auth.register')); ?>">
            <?php echo csrf_field(); ?>
            <label for="reg_name">Имя</label>
            <input type="text" name="name" id="reg_name" required>

            <label for="reg_email">Email</label>
            <input type="email" name="email" id="reg_email" required>

            <label for="reg_password">Пароль</label>
            <input type="password" name="password" id="reg_password" required>

            <label for="password_confirmation">Подтверждение пароля</label>
            <input type="password" name="password_confirmation" id="password_confirmation" required>

            <button type="submit">Регистрация</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/auth.blade.php ENDPATH**/ ?>