<section id="services" class="services">
  <div class="container">
    <h2 class="section-title">Услуги</h2>
    <div class="services__list">
      <article class="service-card">
        <h3>Создание сайтов под ключ</h3>
        <p>Комплекс работ от ТЗ до готового сайта. Agile/Waterfall.</p>
      </article>

      <article class="service-card">
        <h3>Обслуживание веб сайтов</h3>
        <p>Тех. поддержка: нормо-час 3 000 ₽, персональный менеджер.</p>
      </article>

      <article class="service-card">
        <h3>Интеграции</h3>
        <p>Bitrix24, RetailCRM, 1С, МойСклад и др. по запросу.</p>
      </article>

      <article class="service-card">
        <h3>Bitrix24</h3>
        <p>Настройка, внедрение и сопровождение портала.</p>
      </article>
    </div>
  </div>
</section>
<?php /**PATH /var/www/html/resources/views/components/services.blade.php ENDPATH**/ ?>