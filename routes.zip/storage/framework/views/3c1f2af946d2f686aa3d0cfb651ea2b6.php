<header class="site-header">
  <div class="container header__wrap">
    <a class="logo" href="/">
      <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="WEBTENSE logo">
    </a>

    <nav class="main-nav" aria-label="Главное меню">
      <ul>
        <li><a href="#services">Услуги</a></li>
        <li><a href="#portfolio">Портфолио</a></li>
        <li><a href="#company">О нас</a></li>
        <li><a href="#blog">Блог</a></li>
        <li><a href="#contacts">Контакты</a></li>
      </ul>
    </nav>

    <div class="header-contacts">
      <a href="tel:+79778973349" class="phone">+7 (977) 897-33-49</a>
      <a href="mailto:info@webtense.ru" class="email">info@webtense.ru</a>
    </div>
  </div>
</header>
<?php /**PATH /var/www/html/resources/views/components/header.blade.php ENDPATH**/ ?>