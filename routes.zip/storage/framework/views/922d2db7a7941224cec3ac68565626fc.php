<section id="portfolio" class="portfolio">
  <div class="container">
    <h2 class="section-title">Портфолио</h2>

    <div class="portfolio__grid">
      <div class="portfolio__item gradient">
        <img src="<?php echo e(asset('images/portfolio1.jpg')); ?>" alt="">
        <p>Интернет-магазин NEMIFIST</p>
      </div>
      <div class="portfolio__item">
        <img src="<?php echo e(asset('images/portfolio2.jpg')); ?>" alt="">
        <p>Корпоративный сайт «Сфера безопасности»</p>
      </div>
      <!-- add more items -->
    </div>

    <a class="btn btn-ghost portfolio__more" href="#portfolio">В портфолио</a>
  </div>
</section>
<?php /**PATH /var/www/html/resources/views/components/portfolio.blade.php ENDPATH**/ ?>