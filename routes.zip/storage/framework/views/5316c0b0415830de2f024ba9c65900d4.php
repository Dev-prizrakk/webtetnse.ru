<section class="blog">
    <div class="container">
        <h2>Блог</h2>
        <div class="blog__grid">
            <div class="blog__card">
                <img src="<?php echo e(asset('images/blog1.png')); ?>">
                <p>7 трендов веб-разработки 2025 года</p>
            </div>
            <div class="blog__card">
                <img src="<?php echo e(asset('images/blog2.png')); ?>">
                <p>Как выбрать движок для сайта</p>
            </div>
            <div class="blog__card">
                <img src="<?php echo e(asset('images/blog3.png')); ?>">
                <p>Технологии, которые мы любим</p>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/resources/views/components/blog.blade.php ENDPATH**/ ?>