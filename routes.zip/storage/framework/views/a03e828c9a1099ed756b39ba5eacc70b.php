<?php $__env->startSection('content'); ?>
<h1>Профиль пользователя</h1>

<?php if(!$user->email_verified_at): ?>
<div class="alert alert-warning" style="display: flex; align-items: center; justify-content: space-between; max-width: 500px; margin: 20px auto; padding: 15px; background: #f9e5e5; border-radius: 8px;">
    <span>Email не подтверждён. Подтвердите, чтобы использовать все возможности.</span>
    <form method="POST" action="<?php echo e(route('email.verify.frontend')); ?>" style="margin: 0;">
        <?php echo csrf_field(); ?>
        <button type="submit" style="padding: 8px 15px; background: #27ae60; color: #fff; border: none; border-radius: 5px; cursor: pointer;">
            Подтвердить Email
        </button>
    </form>
</div>
<?php endif; ?>

<p><strong>Имя:</strong> <?php echo e($user->name); ?></p>
<p><strong>Email:</strong> <?php echo e($user->email); ?></p>
<p><strong>Подтвержден:</strong> <?php echo e($user->email_verified_at ? 'Да' : 'Нет'); ?></p>


<div style="margin-top: 20px; text-align: center;">
    <p style="color: #555;">Забыли пароль? Вы можете сбросить его:</p>
    <a href="<?php echo e(route('auth.forgot')); ?>" style="display: inline-block; padding: 10px 15px; background: #e67e22; color: #fff; border-radius: 5px; text-decoration: none;">
        Сбросить пароль
    </a>
</div>

<form method="POST" action="<?php echo e(route('auth.logout')); ?>" style="margin-top: 30px; text-align: center;">
    <?php echo csrf_field(); ?>
    <button type="submit" style="padding: 10px 20px; background: #3498db; color: #fff; border: none; border-radius: 5px; cursor: pointer;">
        Выйти
    </button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/profile.blade.php ENDPATH**/ ?>