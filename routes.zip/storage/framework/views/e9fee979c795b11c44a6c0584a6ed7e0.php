<section class="company">
    <div class="container">
        <h2>Коротко о компании</h2>
        <p>Мы создаём сайты и веб-сервисы, решающие задачи клиентов. От идеи и прототипа — до внедрения, поддержки и аналитики.</p>

        <div class="stats">
            <div class="stat"><strong>4.7</strong><span>Средняя оценка</span></div>
            <div class="stat"><strong>115</strong><span>Проектов завершено</span></div>
            <div class="stat"><strong>10 140</strong><span>Часов работы</span></div>
            <div class="stat"><strong>30</strong><span>Партнёров</span></div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/resources/views/components/company.blade.php ENDPATH**/ ?>