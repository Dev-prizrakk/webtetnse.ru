<section class="testimonials">
    <div class="container">
        <h2>Отзывы о нашей работе</h2>
        <div class="testimonials__grid">
            <div class="testimonial">
                <p>Работа выполнена качественно и в срок. Команда всегда на связи.</p>
                <span>ООО «Сфера Безопасности»</span>
            </div>
            <div class="testimonial">
                <p>Быстро запустили лендинг, привлекли первых клиентов — спасибо!</p>
                <span>NUMFEST</span>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/resources/views/components/testimonials.blade.php ENDPATH**/ ?>