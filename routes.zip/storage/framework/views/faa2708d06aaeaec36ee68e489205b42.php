<section class="estimate">
  <div class="container estimate__wrap">
    <div class="estimate__left">
      <h2>Запросить расчет сметы</h2>

      <form action="<?php echo e(route('contact.send')); ?>" method="POST" class="estimate__form">
        <?php echo csrf_field(); ?>
        <label class="label">Выберите услугу</label>
        <div class="estimate__services">
          <button type="button" class="tag active">Разработка сайтов</button>
          <button type="button" class="tag">Тех. поддержка</button>
          <button type="button" class="tag">Интеграции</button>
        </div>

        <div class="two-cols">
          <div>
            <label>Имя*</label>
            <input name="name" required placeholder="Введите ваше имя">
          </div>
          <div>
            <label>Телефон*</label>
            <input name="phone" required placeholder="Введите ваш телефон">
          </div>
        </div>

        <label>E-mail*</label>
        <input name="email" required placeholder="Введите ваш E-mail">

        <div class="estimate__submit">
          <button class="btn btn-primary" type="submit">Отправить заявку</button>
          <p class="small-note">Нажимая на кнопку "Оставить заявку", Вы даёте согласие на обработку персональных данных.</p>
        </div>
      </form>
    </div>

    <div class="estimate__right">
      <img src="<?php echo e(asset('images/calc-decor.png')); ?>" alt="Декор">
    </div>
  </div>
</section>
<?php /**PATH /var/www/html/resources/views/components/estimate.blade.php ENDPATH**/ ?>