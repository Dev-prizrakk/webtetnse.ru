<?php $__env->startSection('content'); ?>
<h1>Добро пожаловать!</h1>
<nav>
    <a href="<?php echo e(route('auth.page')); ?>">Вход / Регистрация</a>
    <a href="<?php echo e(route('profile')); ?>">Профиль</a>
</nav>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>